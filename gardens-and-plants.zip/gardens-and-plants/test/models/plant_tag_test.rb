require "test_helper"

class PlantTagTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
