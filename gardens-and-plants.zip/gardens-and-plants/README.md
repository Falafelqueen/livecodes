Solution code of the Web Development bootcamp Gardens and Plants livecode.

Each branch represents a snapshot of the codebase during this multi-step livecodes:
- `day-one-exercise-one`: app creation, garden model scaffold and seed
- `day-one-exercise-two`: plant model
- `day-two`: tag model & JavaScript
