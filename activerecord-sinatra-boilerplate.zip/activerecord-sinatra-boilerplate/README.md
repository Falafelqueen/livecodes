## Active Record Sinatra boilerplate

Boilerplate for the 03-AR-Database/03-ActiveRecord-Basics/01_sinatra_activerecord livecode.

Please refer to the livecode guidelines to use it.
