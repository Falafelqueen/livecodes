console.log("Connected");
const garageName = "BerlinCars";
const url = `https://wagon-garage-api.herokuapp.com/${garageName}/cars`;

// get all the cars from the garage and console log them

const insertIntoCarList = (cars) => {
  const carList = document.querySelector(".cars-list");
  // iterate over the data
  carList.innerHTML = "";
  cars.forEach((car) => {
    // insert every car into the carList
    const carHTML = `<div class="car">
          <div class="car-image">
            <img src="http://loremflickr.com/280/280/${car.brand},${car.model}$" />
          </div>
          <div class="car-info">
            <h4>${car.brand} ${car.model}</h4>
            <p><strong>Owner:</strong> ${car.owner}</p>
            <p><strong>Plate:</strong> ${car.plate}</p>
          </div>
        </div>`;

    carList.insertAdjacentHTML("beforeend", carHTML);
  });
};

const loadCars = () => {
  fetch(url)
    .then((response) => response.json())
    .then((data) => insertIntoCarList(data));
};

//  get all the cars from the API on page load
loadCars();

//  Add a car to the garage
// Get the input form the form
// const brand = document.querySelector('input[name="brand"]');
// const model = document.querySelector('input[name="model"]');
// const plate = document.querySelector('input[name="plate"]');
// const owner = document.querySelector('input[name="owner"]');

const createCar = (car) => {
  fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(car),
  })
    .then((response) => response.json())
    .then((data) => {
      loadCars();
      // reload the cars
    });
};

const form = document.querySelector(".car-form");

form.addEventListener("submit", (event) => {
  event.preventDefault();
  // send the form data to the API to create the car
  // const car = {
  //   brand: brand.value,
  //   model: model.value,
  //   owner: owner.value,
  //   plate: plate.value,
  // };

  // get the input from the form
  const formData = new FormData(form);
  // create object from FormData
  const car = Object.fromEntries(formData);
  // calling our fetch function to create the car
  createCar(car);
});
